Atividade da aula 10 da disciplina Desenvolvimento Aberto
https://github.com/insper/dev-aberto